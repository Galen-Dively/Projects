import pygame

running = True
screen = pygame.display.set_mode((600, 600))